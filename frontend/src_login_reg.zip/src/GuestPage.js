import React from 'react';
import './GuestPage';

function GuestPage() {
    return (
        <div>
            <h2>Welcome, Guest!</h2>
        </div>
    );
}

export default GuestPage;
